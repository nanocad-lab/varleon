
This leon3 design is tailored to the HPE_mini board from
Gleichmann Electronics:

http://www.ger-fae.com/hpe_mini_lec.html


NOTE: This design is no longer maintained, and needs to be
updated to work with the current grlib version.
