This leon3 design is tailored to the Hpe-midi board from
Gleichmann Electronics:

http://www.ge-research.com

If you intend to use the ep2s_90 or ep2s_60 please change the value BOARD to the appropriate value.
