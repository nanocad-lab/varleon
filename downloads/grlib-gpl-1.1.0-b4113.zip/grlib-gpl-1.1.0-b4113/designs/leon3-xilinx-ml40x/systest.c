
main()

{
	report_start();

	base_test();

	/* i2cmst_test(0x80000c00); */

	report_end();
}
