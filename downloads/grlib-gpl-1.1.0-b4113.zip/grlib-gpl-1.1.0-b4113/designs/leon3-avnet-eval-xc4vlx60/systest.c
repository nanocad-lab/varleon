
main()

{
	report_start();

	base_test();
        greth_test(0x80000f00);

	report_end();
}
