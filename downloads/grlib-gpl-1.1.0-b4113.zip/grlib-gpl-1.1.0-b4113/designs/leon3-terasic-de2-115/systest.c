
main()

{
	report_start();
        
        base_test();

        greth_test(0x80000e00);

        report_end();
}
