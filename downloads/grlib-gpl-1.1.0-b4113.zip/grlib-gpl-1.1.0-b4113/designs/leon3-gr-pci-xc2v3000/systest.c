#define SPWADR 0x80000C00

main()

{
	report_start();

	base_test();

	report_end();
}
