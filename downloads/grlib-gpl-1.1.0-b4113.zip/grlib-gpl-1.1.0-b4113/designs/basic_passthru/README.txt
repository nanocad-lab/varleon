
Passthru example provided by Praesum
------------------------------------

Modelsim should be started as follows to resolve verilog models:

	vsim test_basic_passthru -L gleichmann -L opencores

For further details, contact Praesum.
