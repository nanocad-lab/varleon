#ifndef CONFIG_PS2_ENABLE
#define CONFIG_PS2_ENABLE 0
#endif

