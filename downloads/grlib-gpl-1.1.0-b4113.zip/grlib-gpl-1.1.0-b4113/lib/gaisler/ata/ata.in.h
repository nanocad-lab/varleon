#ifndef CONFIG_ATA_ENABLE
#define CONFIG_ATA_ENABLE 0
#endif

#ifndef CONFIG_ATAIO
#define CONFIG_ATAIO 0
#endif

#ifndef CONFIG_ATAIRQ
#define CONFIG_ATAIRQ 0
#endif

#ifndef CONFIG_ATA_MWDMA
#define CONFIG_ATA_MWDMA 0
#endif

#ifndef CONFIG_ATA_FIFO
#define CONFIG_ATA_FIFO 8
#endif
